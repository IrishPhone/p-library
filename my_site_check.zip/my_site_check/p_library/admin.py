from django.contrib import admin
from p_library.models import Book, Author, Publisher

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'publisher')
    fields = ('ISBN', 'title', 'description', 'year_release', 'author', 'price', 'publisher')
    @staticmethod
    def author_full_name(obj):
        return obj.author.full_name

@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    pass

@admin.register(Publisher)
class PublisherAdmin(admin.ModelAdmin):
    list_display = ('publisher_id', 'id')
    fields = ('publisher_id', 'id')

